﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebexBot.Models
{
    public class Actions
    {
        public int ID { get; set; }
        public string Description { get; set; }
    }
}
